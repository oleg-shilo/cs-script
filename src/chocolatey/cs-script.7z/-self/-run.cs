using static System.Reflection.Assembly; 
using static dbg; 

GetEntryAssembly().Location.print();