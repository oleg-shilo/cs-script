﻿using CSScriptLib;

namespace BreakLib
{
    public class BreakClass
    {
        public static string RunScript()
        {
            var calc = CSScript.Evaluator
                       .Eval(@"using System;
                           public class Script
                           {
                               public int Sum(int a, int b)
                               {
                                   return a+b;
                               }
                           }
                           return new Script();");

            int sum = calc.Sum(1, 2);
            return $"sum is {sum}";
        }
    }
}