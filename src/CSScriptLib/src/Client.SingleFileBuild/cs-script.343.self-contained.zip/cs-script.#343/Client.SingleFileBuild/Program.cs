﻿// See https://aka.ms/new-console-template for more information
using CSScripting;
using CSScriptLib;
using Microsoft.CodeAnalysis;

// dotnet publish --configuration Release --output .\publish

var result = BreakLib.BreakClass.RunScript();
Console.WriteLine(result); ;