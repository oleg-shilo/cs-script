﻿using CSScriptLib;

public class Settings
{
    public static string Value = "Host App value...";
}

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Started...");
            // LocalScripting();
            ClassLibrary1.Class1.LibriryScripting();
            Console.WriteLine("Done...");
        }

        static void LocalScripting()
        {
            var calc = CSScript.Evaluator
                    .Eval(@"using System;
                           public class Script
                           {
                               public int Sum(int a, int b)
                               {
                                   Console.WriteLine(Settings.Value);
                                   return a+b;
                               }
                           }
                           return new Script();");

            int sum = calc.Sum(1, 2);
            Console.WriteLine("CSScript.Evaluator.Eval|class: " + sum);
        }
    }
}