﻿using CSScriptLib;

namespace ClassLibrary1
{
    public class Class1
    {
        public static void LibriryScripting()
        {
            var calc = CSScript.Evaluator
                    .Eval(@"using System;
                           public class Script
                           {
                               public int Sum(int a, int b)
                               {
                                   Console.WriteLine(Settings.Value);
                                   return a+b;
                               }
                           }
                           return new Script();");

            int sum = calc.Sum(1, 2);
            Console.WriteLine("CSScript.Evaluator.Eval|class: " + sum);
        }
    }
}