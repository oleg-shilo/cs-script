using System;
using System.ComponentModel;

namespace Config
{
	public partial class TestData
	{
		[Description("Key")]
		public string StringVal;
		public int IntVal;    
		public float FloatVal;
		public bool BoolVal;
	}
}

