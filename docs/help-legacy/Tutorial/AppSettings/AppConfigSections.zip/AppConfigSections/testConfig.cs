/*
Auto-generated file.
3/14/2007 3:17:51 PM
AppConfigCompiler.exe "C:\cs-script\Dev\AppConfig\Final\Program\test.cs" "C:\cs-script\Dev\AppConfig\Final\Program\Program.csproj"
DO NOT MODIFY!
------------------------------- 
app.config sample:

<?xml version="1.0" encoding="utf-8" ?>
<configuration>
	<configSections>
		<sectionGroup name="TestDataGroup" type="Config.TestDataSectionGroup, Program">
			<section name="TestDataSection" type="Config.TestDataSection, Program" />
		</sectionGroup>
	</configSections>
		
		
	<TestDataGroup>
		<TestDataSection>
			<TestDataCollection>
				<clear />
				<add StringVal="some_key_value1" IntVal="some_value" FloatVal="some_value" BoolVal="some_value"  />
				<add StringVal="some_key_value2" IntVal="some_value" FloatVal="some_value" BoolVal="some_value"  />
			</TestDataCollection>
		</TestDataSection>
	</TestDataGroup>
	
</configuration>
------------------------------- 
C# usage sample:
	
	Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
	TestDataCollection collection = (config.SectionGroups["TestDataGroup"].Sections["TestDataSection"] as TestDataSection).TestDataCollection;

	foreach (TestDataElement element in collection) 
		Console.WriteLine(element.ToString()); 
	
	TestDataElement test = collection[<some_key_value>]; 
	TestData data = (TestData)collection[<some_key_value>]; 
	 
	collection[<some_key_value>].FloatVal = <some_new_value>; 
   
	config.Save(ConfigurationSaveMode.Full); 
	-------------------------------
Code generation:

Use the following command in the VS2005 pre-build event:

 AppConfigCompiler.exe $(ProjectDir)<file_name> $(ProjectPath) 

where <file_name> is a file name of the file containg declaration
of the data class to be serialized through app.config.
*/ 

using System; 
using System.ComponentModel; 
using System.Configuration; 

namespace Config 
{ 
	public class TestDataSectionGroup : ConfigurationSectionGroup 
	{ 
	} 
	public class TestDataSection : ConfigurationSection 
	{ 
		[ConfigurationProperty("TestDataCollection", IsDefaultCollection = false, IsRequired = false)] 
		public TestDataCollection TestDataCollection 
		{ 
			get 
			{ 
				return (TestDataCollection)this["TestDataCollection"]; 
			} 
		} 
	} 
	public class TestDataCollection : ConfigurationElementCollection 
	{ 
		protected override object GetElementKey(ConfigurationElement element) 
		{ 
			return ((TestDataElement)element).StringVal; 
		} 
		protected override ConfigurationElement CreateNewElement() 
		{ 
			return new TestDataElement(); 
		} 
		public TestDataElement this[object key] 
		{ 
			get 
			{ 
				return (TestDataElement)BaseGet(key); 
			} 
			set 
			{ 
				if (BaseGet(key) != null) 
				{ 
					BaseRemove(key); 
				} 
				BaseAdd(value); 
			} 
		} 
	} 
	public class TestDataElement : ConfigurationElement 
	{ 
        [ConfigurationProperty("StringVal")] 
	    public String StringVal 
	    { 
		    get 
		    { 
			    return Convert.ToString(this["StringVal"]); 
		    } 
		    set 
		    { 
			    this["StringVal"] = value; 
		    } 
	    } 
        [ConfigurationProperty("IntVal")] 
	    public Int32 IntVal 
	    { 
		    get 
		    { 
			    return Convert.ToInt32(this["IntVal"]); 
		    } 
		    set 
		    { 
			    this["IntVal"] = value; 
		    } 
	    } 
        [ConfigurationProperty("FloatVal")] 
	    public Single FloatVal 
	    { 
		    get 
		    { 
			    return Convert.ToSingle(this["FloatVal"]); 
		    } 
		    set 
		    { 
			    this["FloatVal"] = value; 
		    } 
	    } 
        [ConfigurationProperty("BoolVal")] 
	    public Boolean BoolVal 
	    { 
		    get 
		    { 
			    return Convert.ToBoolean(this["BoolVal"]); 
		    } 
		    set 
		    { 
			    this["BoolVal"] = value; 
		    } 
	    } 

		public static explicit operator TestData(TestDataElement element) 
		{ 
			TestData retval = new TestData(); 
			retval.StringVal = element.StringVal; 
			retval.IntVal = element.IntVal; 
			retval.FloatVal = element.FloatVal; 
			retval.BoolVal = element.BoolVal; 

			return retval; 
		} 
	} 
}; 
