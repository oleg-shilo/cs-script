//css_include test.cs;
//css_include testConfig.cs;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Collections;
using System.Configuration;
using System.ComponentModel;
using System.Windows.Forms;
using Config;
using CSScriptLibrary;

class Program
{
	static void Main()
	{
		CSScript.AssemblyResolvingEnabled = true;

		Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
		TestDataCollection collection = (config.SectionGroups["TestDataGroup"].Sections["TestDataSection"] as TestDataSection).TestDataCollection;

		foreach (TestDataElement element in collection)
		    Console.WriteLine(element.StringVal);

		TestDataElement test = collection["AO1"];

		TestData data = (TestData)collection["AO0"];

		collection["AO1"].FloatVal = 77.7f;
		config.Save(ConfigurationSaveMode.Full);
	}
}
