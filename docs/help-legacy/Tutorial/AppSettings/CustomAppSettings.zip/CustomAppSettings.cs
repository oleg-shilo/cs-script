using System;
using System.IO;
using System.Reflection;
using System.Configuration;

public class Script
{
	//does not work if the assembly is executed from unmanaged code.
	static public void Main()
	{
		AppDomainSetup setup = new AppDomainSetup();
		setup.ConfigurationFile = Path.GetFullPath("CustomAppSettings.cs.config");
		AppDomain appDomain = AppDomain.CreateDomain("", null, setup);

		CustomSettings settings = (CustomSettings)appDomain.CreateInstanceFromAndUnwrap(Assembly.GetExecutingAssembly().Location, typeof(CustomSettings).ToString());

		Console.WriteLine(settings.AppSettings["gritting"]);
	}
}

public class CustomSettings : MarshalByRefObject
{
	internal object GetSection(string sectionName)
	{
		return ConfigurationManager.GetSection(sectionName);
	}
	public CustomAppSettings AppSettings = new CustomAppSettings();
	public class CustomAppSettings : MarshalByRefObject
	{
		public string this[string name]
		{
			get
			{
				return ConfigurationManager.AppSettings[name];
			}
		}
	}
}
