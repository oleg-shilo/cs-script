//////////////////////////////////////////////////////////////////////////
//imageprocessor.cs - script file from 'ImageProcessor' tutorial

//css_dbg /t:winexe;
using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using CSScriptLibrary;
using csscript;

namespace ScriptingTutorials
{
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button buttonUndo;
		private System.Windows.Forms.Button buttonProcess;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.ListBox listBox1;
		private System.ComponentModel.Container components = null;

		class Script
		{
            string file;
			public Script(string file)
			{
				this.file = Path.GetFullPath(file);
			}
            
            public Image Modify(Image image)
            {
                //It is possible to cache compiled script in this class, however
                //CSScript can do it for you. Regardless how many times you call CSScript.Load()
                //it compiles script only if it was changed since the last execution.
                var modify = CSScript.Load(file, null, true)
                                     .GetStaticMethod("*.Modify", image);
                return (Image)modify(image);
            }

			override public string ToString()
			{
				return Path.GetFileNameWithoutExtension(file);
			}
		}

       	public Form1()
		{
			InitializeComponent();

			LoadImage(@"rose.bmp");

			foreach (string file in Directory.GetFiles("Scripts", "*.cs"))
				listBox1.Items.Add(new Script(file));

			if (listBox1.Items.Count != 0)
				listBox1.SelectedIndex = 0;
		}

		public void LoadImage(String fileToDisplay)
		{
			using (Image oldImage = pictureBox1.Image)    // this will dispose old image if required
			{
				// Stretches the image to fit the pictureBox.
				pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
				Image newImage = new Bitmap(fileToDisplay);
				pictureBox1.ClientSize = new Size(200, 200);
				pictureBox1.Image = newImage;
			}
		}


		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		#region Windows Form Designer generated code
		private void InitializeComponent()
		{
			this.buttonUndo = new System.Windows.Forms.Button();
			this.buttonProcess = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// buttonUndo
			// 
			this.buttonUndo.Location = new System.Drawing.Point(320, 192);
			this.buttonUndo.Name = "buttonUndo";
			this.buttonUndo.Size = new System.Drawing.Size(75, 23);
			this.buttonUndo.TabIndex = 1;
			this.buttonUndo.Text = "Undo";
			this.buttonUndo.Click += new System.EventHandler(this.buttonUndo_Click);
			// 
			// buttonProcess
			// 
			this.buttonProcess.Location = new System.Drawing.Point(408, 192);
			this.buttonProcess.Name = "buttonProcess";
			this.buttonProcess.Size = new System.Drawing.Size(75, 23);
			this.buttonProcess.TabIndex = 1;
			this.buttonProcess.Text = "Execute";
			this.buttonProcess.Click += new System.EventHandler(this.buttonProcess_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(248, 208);
			this.pictureBox1.TabIndex = 4;
			this.pictureBox1.TabStop = false;
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(288, 8);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(216, 173);
			this.listBox1.TabIndex = 5;
			this.listBox1.DoubleClick += new System.EventHandler(this.buttonProcess_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(514, 224);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.buttonUndo);
			this.Controls.Add(this.buttonProcess);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Image Processor";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		private void buttonUndo_Click(object sender, System.EventArgs e)
		{
			LoadImage(@"rose.bmp");
		}

		private void buttonProcess_Click(object sender, System.EventArgs e)
		{
			if (listBox1.SelectedIndex != -1)
			{
				Cursor.Current = Cursors.WaitCursor;
				try
				{
					Script script = (Script)listBox1.SelectedItem;

					using (Image oldImage = pictureBox1.Image) // this will dispose old image if required
					{
						pictureBox1.Image = script.Modify(oldImage);
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.ToString());
				}
				Cursor.Current = Cursors.Default;
			}
		}
	}
	class Program
	{
		static public void Main(string[] args)
		{
			Application.Run(new Form1());
		}
	}
}
