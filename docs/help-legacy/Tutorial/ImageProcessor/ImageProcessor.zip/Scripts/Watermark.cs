using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Dr ing.Drawing2D;

public class ImageEditorScript
{
	public static Image Modify(Image image)
	{
		Bitmap newBitmap = new Bitmap(image.Width, image.Height, PixelFormat.Format32bppArgb);			
		using (Graphics g = Graphics.FromImage(newBitmap))
		{
			g.DrawImage(image, 0.0f, 0.0f); //draw original image

			g.DrawString("Watermark", new Font("Arial", 30), new SolidBrush(Color.FromArgb(90, 255, 255, 255)), 20, 20);
		} 
		return newBitmap;
    }
}