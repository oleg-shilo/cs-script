using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

public class ImageEditorScript
{
    public static Image Modify(Image image) 
	{
		Bitmap newBitmap = new Bitmap(image.Width, image.Height, PixelFormat.Format32bppArgb);			
		using (Graphics g = Graphics.FromImage(newBitmap))
		{
			ImageAttributes imageAttributes = new ImageAttributes();
			int width = image.Width;
			int height = image.Height;

			float[][] colorMatrixElements = { 	new float[] {0.4f,  0,  0,  0, 0},        	// red scaling factor of 1
												new float[] {0,  0.4f,  0,  0, 0},        	// green scaling factor of 1
												new float[] {0,  0,  0.4f,  0, 0},        	// blue scaling factor of 1
												new float[] {0,  0,  0,  1f, 0},        	// alpha scaling factor of 1
												new float[] {0,  0,  0,  0, 1f}};       	// three translations of 1

			ColorMatrix colorMatrix = new ColorMatrix(colorMatrixElements);
			imageAttributes.SetColorMatrix(colorMatrix, ColorMatrixFlag.Default,ColorAdjustType.Bitmap);

			g.DrawImage(image, new Rectangle(0, 0, width, height), 0, 0, width, height, GraphicsUnit.Pixel, imageAttributes);
		} 
		return newBitmap;
    }
}