// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using System;
using System.IO;

namespace Microsoft.CodeDom.Providers.DotNetCompilerPlatform {

    internal sealed class CompilerSettings : ICompilerSettings {
        private string _compilerFullPath;
        private int _compilerServerTimeToLive = 0; // seconds

        public CompilerSettings(string compilerFullPath, int compilerServerTimeToLive) {
            if (string.IsNullOrEmpty(compilerFullPath)) {
                throw new ArgumentNullException("compilerFullPath");
            }

            _compilerFullPath = compilerFullPath;
            _compilerServerTimeToLive = compilerServerTimeToLive;
        }

        public string CompilerFullPath {
            get {
                return _compilerFullPath;
            }

            internal set {
                _compilerFullPath = value;
            }
        }

        public int CompilerServerTimeToLive {
            get {
                return _compilerServerTimeToLive;
            }

            internal set {
                _compilerServerTimeToLive = value;
            }
        }
    }

    internal static class CompilationSettingsHelper {
        private const int DefaultCompilerServerTTL = 10; //seconds

        private static ICompilerSettings _csc = new CompilerSettings(CompilerFullPath(@"bin\roslyn\csc.exe"), DefaultCompilerServerTTL);
        private static ICompilerSettings _vb = new CompilerSettings(CompilerFullPath(@"bin\roslyn\vbc.exe"), DefaultCompilerServerTTL);

        public static ICompilerSettings CSC2 {
            get {
                return _csc;
            }
        }

        public static ICompilerSettings VBC2 {
            get {
                return _vb;
            }
        }

        private static string CompilerFullPath(string relativePath) {
            string compilerFullPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, relativePath);
            return compilerFullPath;
        }
    }
}